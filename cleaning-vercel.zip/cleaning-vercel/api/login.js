const L=require('./_lib');
module.exports=async(req,res)=>{
  if(req.method!=='POST')return L.json(res,405,{});
  try{
    if(!L.PASS)return L.json(res,500,{error:'no ADMIN_PASSWORD'});
    if(await L.limited('rl:login:'+L.ip(req),5,600))return L.json(res,429,{error:'rate'});
    const b=L.body(req);
    if(!L.eq(L.sha(String(b.password||'')),L.sha(L.PASS)))return L.json(res,401,{error:'bad'});
    L.setSession(res);return L.json(res,200,{ok:true});
  }catch(e){return L.json(res,500,{error:'server'})}
};
