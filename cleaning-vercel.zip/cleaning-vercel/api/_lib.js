const crypto=require('crypto');
const URL_=process.env.KV_REST_API_URL||process.env.UPSTASH_REDIS_REST_URL;
const TOK=process.env.KV_REST_API_TOKEN||process.env.UPSTASH_REDIS_REST_TOKEN;
const PASS=process.env.ADMIN_PASSWORD||'';
const DEF=[['Поддерживающая уборка','Пыль, полы, санузел, кухня снаружи. Для квартиры, где уже чисто.','от 40 ₽/м²'],['Генеральная уборка','Приборы, шкафы внутри, окна, плинтусы, труднодоступные места.','от 90 ₽/м²'],['После ремонта','Вывоз строительной пыли, мытьё окон, удаление следов затирки и краски.','от 140 ₽/м²'],['Уборка офисов','Разовая или по графику, в нерабочее время.','по запросу']].map(r=>({t:r[0],d:r[1],p:r[2]}));
const ST={new:'Новая',work:'В работе',done:'Выполнена',cancel:'Отказ'};
async function r(...cmd){
  const x=await fetch(URL_,{method:'POST',headers:{Authorization:'Bearer '+TOK},body:JSON.stringify(cmd)});
  const j=await x.json();if(j.error)throw new Error(j.error);return j.result;
}
const key=crypto.createHash('sha256').update('sess:'+PASS).digest();
const sign=e=>crypto.createHmac('sha256',key).update(String(e)).digest('hex');
function authed(req){
  const m=(req.headers.cookie||'').match(/(?:^|;\s*)sid=(\d+)\.([a-f0-9]+)/);
  if(!PASS||!m||+m[1]<Date.now())return false;
  const a=Buffer.from(sign(m[1])),b=Buffer.from(m[2]);
  return a.length===b.length&&crypto.timingSafeEqual(a,b);
}
function setSession(res){const e=Date.now()+7*864e5;res.setHeader('Set-Cookie','sid='+e+'.'+sign(e)+'; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800')}
const ip=req=>String(req.headers['x-real-ip']||req.headers['x-forwarded-for']||'').split(',')[0].trim();
async function limited(k,max,sec){const n=await r('INCR',k);if(n===1)await r('EXPIRE',k,sec);return n>max}
const body=req=>{let b=req.body;if(typeof b==='string'){try{b=JSON.parse(b)}catch(e){b={}}}return b&&typeof b==='object'?b:{}};
const str=(v,n)=>String(v==null?'':v).trim().slice(0,n);
const json=(res,c,o)=>res.status(c).json(o);
module.exports={r,authed,setSession,ip,limited,body,str,json,DEF,ST,PASS,sha:s=>crypto.createHash('sha256').update(s).digest(),eq:(a,b)=>crypto.timingSafeEqual(a,b)};
