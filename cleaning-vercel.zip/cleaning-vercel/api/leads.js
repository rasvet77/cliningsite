const L=require('./_lib');
module.exports=async(req,res)=>{
  if(!L.authed(req))return L.json(res,401,{error:'auth'});
  try{
    const id=String(req.query.id||'');
    if(req.method==='PATCH'||req.method==='DELETE'){
      if(!/^[\w-]+$/.test(id))return L.json(res,400,{error:'id'});
      if(req.method==='DELETE'){await L.r('HDEL','leads',id);return L.json(res,200,{ok:true})}
      const raw=await L.r('HGET','leads',id);if(!raw)return L.json(res,404,{});
      const l=JSON.parse(raw),b=L.body(req);if(L.ST[b.status])l.status=b.status;
      await L.r('HSET','leads',id,JSON.stringify(l));return L.json(res,200,{ok:true});
    }
    const flat=(await L.r('HGETALL','leads'))||[];const vals=Array.isArray(flat)?flat.filter((_,i)=>i%2):Object.values(flat);
    const leads=vals.map(v=>JSON.parse(v)).sort((a,b)=>b.ts-a.ts);
    if(req.query.format==='csv'){
      const q=s=>{s=String(s==null?'':s);if(/^([=@]|[+-](?!\d))/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};
      const rows=[['Дата','Имя','Телефон','Вид уборки','Комментарий','Статус'],...leads.map(l=>[new Date(l.ts).toLocaleString('ru-RU'),l.name,l.phone,l.type,l.note,L.ST[l.status]||l.status])];
      res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="zayavki.csv"');
      return res.status(200).send('\ufeff'+rows.map(r=>r.map(q).join(';')).join('\n'));
    }
    return L.json(res,200,leads);
  }catch(e){return L.json(res,500,{error:'server'})}
};
