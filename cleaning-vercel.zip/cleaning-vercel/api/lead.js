const crypto=require('crypto'),L=require('./_lib');
module.exports=async(req,res)=>{
  if(req.method!=='POST')return L.json(res,405,{});
  try{
    if(await L.limited('rl:lead:'+L.ip(req),10,3600))return L.json(res,429,{error:'rate'});
    const b=L.body(req);
    const l={id:crypto.randomUUID(),ts:Date.now(),name:L.str(b.name,100),phone:L.str(b.phone,40),type:L.str(b.type,60),note:L.str(b.note,1000),status:'new'};
    if(!l.name||l.phone.replace(/\D/g,'').length<10)return L.json(res,400,{error:'invalid'});
    await L.r('HSET','leads',l.id,JSON.stringify(l));
    const T=process.env.TG_TOKEN,C=process.env.TG_CHAT;
    if(T&&C)await fetch('https://api.telegram.org/bot'+T+'/sendMessage',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:C,text:'Новая заявка\n'+l.name+'\n'+l.phone+'\n'+l.type+'\n'+l.note})}).catch(()=>{});
    return L.json(res,200,{ok:true});
  }catch(e){return L.json(res,500,{error:'server'})}
};
