const L=require('./_lib');
module.exports=async(req,res)=>{
  try{
    if(req.method==='GET'){
      let raw=null;try{raw=await L.r('GET','prices')}catch(e){}
      return L.json(res,200,raw?JSON.parse(raw):L.DEF);
    }
    if(req.method==='PUT'){
      if(!L.authed(req))return L.json(res,401,{error:'auth'});
      const b=L.body(req),a=Array.isArray(b)?b:(Array.isArray(req.body)?req.body:[]);
      const rows=a.slice(0,50).map(x=>({t:L.str(x.t,100),d:L.str(x.d,300),p:L.str(x.p,50)})).filter(x=>x.t);
      await L.r('SET','prices',JSON.stringify(rows));return L.json(res,200,{ok:true});
    }
    return L.json(res,405,{});
  }catch(e){return L.json(res,500,{error:'server'})}
};
